function Home() {
return(
<div>
<main>
<h1>Home page  </h1>
<p>
 This Univercity was established in 2024. The name of our Univercity is  ShootingStar univercity. 
At  ShootingStar univercity, we beleive for nurturing bright minds and helping students to  shine  like a star. 
Our diverse programs and world class  faculty and modern facilities  provides a wonderfull and   friendly environment to learn and grow. 
We also provides modern facilities like AI  models which also helps students to learn and grow and to excel in their fields. 
</p>
</main>
</div>
);
}
export default Home;