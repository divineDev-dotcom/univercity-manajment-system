import React from 'react';
import {BrowserRouter as Router, Routes, Route, Link} from 'react-router-dom';
import Home from './pages/home';
import Button from './components/button';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsAndConditions from './pages/TermsAndConditions';
import ShootingStar from './ShootingStar.jpg';

function App() {
return (
<Router>
<div>
<header>
<nav>
<ul>
<li><Link to="/">Home</Link></li>
</ul>
</nav>
<img src={ShootingStar} alt="A blue logo of a Shooting Star, which makes all our wishes come true" style={{ width: '150px', height: '150px' }} />
</header>
<main>
<h1>  Welcome To our Univercity's WebSite. Here you  Will find all important information regarding our Univercity </h1>
</main>
<Routes>
<Route path="/" element={<Home />} />
<Route path="/privacyPolicy" element={<PrivacyPolicy />} />
<Route path="/termsAndConditions" element={<TermsAndConditions />} /> 
</Routes>
<footer>
<nav>
<ul>
<li><Link to="/privacyPolicy">Privacy Policy</Link></li>
<li><Link to="/termsAndConditions">Terms and Conditions</Link></li>
<p>Copyright 2024</p>
</ul>
</nav>
</footer> 
</div> 
</Router>
  );
}

export default App;
