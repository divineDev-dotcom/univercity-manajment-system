import {useState, useEffect} from 'react';
import {Link} from 'react-router-dom';

function StudentDetails() {
const [firstName, setFirstName] = useState("");
const [middleName, setMiddleName] = useState("");
const [lastName, setLastName] = useState("");

const [email, setEmail] = useState("");

return(

);
}
export default StudentDetails;